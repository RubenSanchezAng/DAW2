  <form enctype="multipart/form-data" action="./enviarEjercicioFormulario.php" method="post">
    <!-- El nombre del elemento input determina el nombre en el array $_FILES -->
    Envíe este fichero: <input name="fichero" type="file" />
    <input type="submit" value="Enviar" name= "boton" />
  </form>





