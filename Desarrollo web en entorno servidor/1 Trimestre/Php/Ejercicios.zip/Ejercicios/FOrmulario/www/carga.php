<form action="" method="post">
    Sube fichero<input type="file" name="fichero" id="">
    <input type="submit" name="enviar" value="">
</form>