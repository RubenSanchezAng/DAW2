<form action="" method="post">
    <input type="text" name="nombre" id="" placeholder="apellidos">
    <select name="correos" id="">
        <option value="M">M</option>
    </select>
    <input type="checkbox" name="correo[]" value = "a" id="">a
        <input type="checkbox" name="correo[]" value = "b" id="">b

            <input type="checkbox" name="correo[]" value = "c" id="">c

                <input type="checkbox" name="correo[]" value = "d" id="">d
    <input type="color" name="color" id="">

</form>