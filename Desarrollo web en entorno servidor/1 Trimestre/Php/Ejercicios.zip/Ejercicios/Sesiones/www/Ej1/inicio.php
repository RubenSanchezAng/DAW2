<form action="primeraPagina.php" method= "post">
    <input type="text" name="nombre" id="">
    <input type="number" name="valor" id="">
    <input type="submit" value="Enviar">
</form>