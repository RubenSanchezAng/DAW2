<?php
session_start();
?>
<form action="panel.php" method="post">
    <input type="text" name="nombre" id="">
    <input type="password" name="contrasenya" id="">
    <input type="submit" name="enviar">
</form>