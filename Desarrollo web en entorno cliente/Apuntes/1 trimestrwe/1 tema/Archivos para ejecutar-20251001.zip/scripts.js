

console.log("Log con defer")

