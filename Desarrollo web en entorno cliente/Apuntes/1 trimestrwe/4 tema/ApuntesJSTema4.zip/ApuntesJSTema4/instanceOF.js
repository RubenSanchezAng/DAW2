class Rabbit {}
let rabbit = new Rabbit();

// ¿Es un objeto de la clase Rabbit?
alert( rabbit instanceof Rabbit ); // true

// en lugar de clase
function Rabbit() {}

alert( new Rabbit() instanceof Rabbit ); // truelet 


// arr = [1, 2, 3];
alert( arr instanceof Array ); // true
alert( arr instanceof Object ); // truec

class Animal {}
class Perro extends Animal {}

let perro = new Rabbit();
alert(rabbit instanceof Animal); // true

let obj = {};

alert(obj); // [object Object]
alert(obj.toString()); // lo mismo